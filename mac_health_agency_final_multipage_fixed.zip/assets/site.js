
const menuButton = document.querySelector('[data-menu-button]');
const mainNav = document.querySelector('[data-main-nav]');
if (menuButton && mainNav) {
  menuButton.addEventListener('click', () => {
    const open = mainNav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
  });
}
document.querySelectorAll('.drop-toggle').forEach((btn) => {
  btn.addEventListener('click', () => {
    const parent = btn.closest('.drop');
    const open = parent.classList.toggle('open');
    btn.setAttribute('aria-expanded', String(open));
  });
});
