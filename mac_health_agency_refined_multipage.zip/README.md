# The MacCalla Agency — refined multi-page static website

This version intentionally removes the excessive body links from the previous build.

## Pages included
- `index.html`
- `the-basics.html`
- `original-medicare.html`
- `medicare-advantage.html`
- `part-d.html`
- `med-supp.html`
- `ancillary.html`
- `aca.html`
- `about-us.html`
- `contact-us.html`
- `privacy-policy.html`
- `terms-of-service.html`
- `thank-you.html`
- `404.html`

## Link approach
Only the navigation, CTA buttons, contact info, legal/footer, and official resources are clickable. Regular content cards are not clickable, so the site feels cleaner.

## Netlify form
The contact form uses `data-netlify="true"`. After deploying, enable form notifications in Netlify to forward submissions to the client email.

## Contact
Phone: 321-382-4787  
Email: melissa@machealthagency.com  
Address: 3370 Garden St. Titusville, FL 32796
